#!/bin/bash

dashboard_api_validation() {

echo "[DASHBOARD API] Running dashboard API validation"

echo
echo "Checking dashboard API configuration..."

if [ -d "apps/dashboard" ]; then
    echo "Dashboard directory: OK"
else
    echo "Dashboard directory missing"
fi

echo
echo "Checking API URL configuration..."

if [ -f "apps/dashboard/.env.local" ]; then
    echo ".env.local detected"
else
    echo ".env.local not found"
fi

echo
echo "Checking dashboard auth client..."

if grep -R "api/auth\|NEXT_PUBLIC_API_URL" apps/dashboard >/dev/null 2>&1
then
    echo "Dashboard API references detected"
else
    echo "Dashboard API references not detected"
fi

echo
echo "Dashboard API validation complete"

}


dashboard_api_repair() {

echo "[DASHBOARD API] Running dashboard API repair"

echo
echo "Checking dashboard dependencies..."

if [ -d "apps/dashboard/node_modules" ]; then
    echo "node_modules present"
else
    echo "node_modules missing"
fi


echo
echo "Checking Next configuration..."

if [ -f "apps/dashboard/next.config.js" ] || [ -f "apps/dashboard/next.config.mjs" ]
then
    echo "Next configuration detected"
else
    echo "Next configuration missing"
fi


echo
echo "Dashboard API repair checks complete"

}
