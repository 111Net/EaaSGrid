export default function Admin(){

return (
<div style={{padding:"40px"}}>

<h1>
Administration
</h1>

<p>
System administration and governance controls.
</p>

</div>
)

}
