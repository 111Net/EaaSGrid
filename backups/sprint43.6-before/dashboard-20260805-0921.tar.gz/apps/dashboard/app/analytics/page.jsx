export default function Analytics(){

return (
<div style={{padding:"40px"}}>

<h1>
Analytics Engine
</h1>

<p>
Platform analytics, AI recommendations and reporting will appear here.
</p>

</div>
)

}
