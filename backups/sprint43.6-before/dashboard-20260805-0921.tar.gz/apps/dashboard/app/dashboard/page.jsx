"use client";

import Sidebar from "../../components/Sidebar";
import KPICard from "../../components/KPICard";


export default function Dashboard(){

const metrics=[
["Organizations","25","Healthy"],
["Tenants","142","Active"],
["Customers","1840","Online"],
["Availability","99.95%","Operational"]
];


return (

<div style={{
display:"flex",
background:"#f3f4f6",
minHeight:"100vh"
}}>


<Sidebar/>


<main style={{
padding:"40px",
flex:1
}}>


<h1>
XaaSGrid Enterprise Dashboard
</h1>


<p>
Platform overview and operational intelligence
</p>


<div style={{
display:"grid",
gridTemplateColumns:"repeat(4,1fr)",
gap:"20px"
}}>


{
metrics.map(m=>

<KPICard
key={m[0]}
title={m[0]}
value={m[1]}
status={m[2]}
/>

)

}


</div>


<h2 style={{
marginTop:"40px"
}}>
Platform Modules
</h2>


<ul>

<li><Link href="/enterprise">Enterprise Management</Link></li>
<li><Link href="/operations">Operations Intelligence</Link></li>
<li><Link href="/analytics">Analytics Engine</Link></li>
<li><Link href="/admin">Administration</Link></li>

</ul>


</main>


</div>

)

}
