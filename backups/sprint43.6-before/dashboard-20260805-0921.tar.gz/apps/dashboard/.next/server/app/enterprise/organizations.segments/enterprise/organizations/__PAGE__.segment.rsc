1:"$Sreact.fragment"
2:I[97367,["/_next/static/chunks/1iicwdi9g1cfh.js"],"OutletBoundary"]
3:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","div",null,{"children":[["$","h1",null,{"children":"Organizations"}],["$","p",null,{"children":"Create, manage and monitor enterprise organizations."}],["$","table",null,{"children":["$","tbody",null,{"children":["$","tr",null,{"children":[["$","td",null,{"children":"XaaSGrid Demo Enterprise"}],["$","td",null,{"children":"ACTIVE"}]]}]}]}]]}],null,["$","$L2",null,{"children":["$","$3",null,{"name":"Next.MetadataOutlet","children":"$@4"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"rcFk8HKwLw_Qd-j8KTdOd"}
4:null
