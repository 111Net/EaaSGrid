1:"$Sreact.fragment"
2:I[97367,["/_next/static/chunks/1iicwdi9g1cfh.js"],"OutletBoundary"]
3:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","main",null,{"style":{"padding":"40px"},"children":[["$","h1",null,{"children":"XaaSGrid Operations Intelligence Center"}],["$","p",null,{"children":"Platform operational visibility dashboard"}],["$","h2",null,{"children":"System Status"}],["$","ul",null,{"children":[["$","li",null,{"children":"API: ONLINE"}],["$","li",null,{"children":"Database: ONLINE"}],["$","li",null,{"children":"Redis: ONLINE"}],["$","li",null,{"children":"Dashboard: ONLINE"}]]}],["$","h2",null,{"children":"Monitoring Foundation"}],["$","p",null,{"children":"Health collectors and event monitoring enabled."}]]}],null,["$","$L2",null,{"children":["$","$3",null,{"name":"Next.MetadataOutlet","children":"$@4"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"rcFk8HKwLw_Qd-j8KTdOd"}
4:null
