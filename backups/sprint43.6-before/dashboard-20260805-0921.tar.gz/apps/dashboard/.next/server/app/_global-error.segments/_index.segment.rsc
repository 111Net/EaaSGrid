1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/1iicwdi9g1cfh.js"],"default"]
3:I[37457,["/_next/static/chunks/1iicwdi9g1cfh.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"rcFk8HKwLw_Qd-j8KTdOd"}
