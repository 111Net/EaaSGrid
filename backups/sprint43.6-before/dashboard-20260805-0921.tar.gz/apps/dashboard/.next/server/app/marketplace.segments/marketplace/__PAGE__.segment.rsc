1:"$Sreact.fragment"
2:I[97367,["/_next/static/chunks/1iicwdi9g1cfh.js"],"OutletBoundary"]
3:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","main",null,{"children":[["$","h1",null,{"children":"XaaSGrid Marketplace"}],["$","h2",null,{"children":"Everything-as-a-Service Catalog"}],["$","ul",null,{"children":[["$","li",null,{"children":"Solar-as-a-Service"}],["$","li",null,{"children":"Security-as-a-Service"}],["$","li",null,{"children":"AI-as-a-Service"}],["$","li",null,{"children":"Backup-as-a-Service"}]]}]]}],null,["$","$L2",null,{"children":["$","$3",null,{"name":"Next.MetadataOutlet","children":"$@4"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"rcFk8HKwLw_Qd-j8KTdOd"}
4:null
