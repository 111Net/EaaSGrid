1:"$Sreact.fragment"
2:I[97367,["/_next/static/chunks/1iicwdi9g1cfh.js"],"OutletBoundary"]
3:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","div",null,{"children":[["$","h1",null,{"children":"XaaSGrid Enterprise Control Plane"}],["$","p",null,{"children":"Enterprise administration and governance console"}],["$","div",null,{"children":[["$","h2",null,{"children":"Platform Overview"}],["$","ul",null,{"children":[["$","li",null,{"children":"Organizations: Managed"}],["$","li",null,{"children":"Tenants: Managed"}],["$","li",null,{"children":"RBAC: Enabled"}],["$","li",null,{"children":"Governance: Active"}]]}]]}]]}],null,["$","$L2",null,{"children":["$","$3",null,{"name":"Next.MetadataOutlet","children":"$@4"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"rcFk8HKwLw_Qd-j8KTdOd"}
4:null
