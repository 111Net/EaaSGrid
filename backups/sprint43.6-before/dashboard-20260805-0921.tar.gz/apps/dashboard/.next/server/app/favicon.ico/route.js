var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]_next_dist_0iuj5m_._.js")
R.c("server/chunks/[root-of-the-server]__1ve_4w2._.js")
R.c("server/chunks/apps_dashboard__next-internal_server_app_favicon_ico_route_actions_1doicvp.js")
R.m(72246)
module.exports=R.m(72246).exports
