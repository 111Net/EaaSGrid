1:"$Sreact.fragment"
2:I[97367,["/_next/static/chunks/1iicwdi9g1cfh.js"],"OutletBoundary"]
3:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","div",null,{"children":[["$","h1",null,{"children":"XaaSGrid Enterprise Administration"}],["$","h2",null,{"children":"Organizations"}],["$","p",null,{"children":"Manage enterprise accounts and tenants."}],["$","h2",null,{"children":"Tenant Management"}],["$","p",null,{"children":"Create, monitor and govern tenant environments."}],["$","h2",null,{"children":"RBAC Governance"}],["$","p",null,{"children":"Manage roles and permissions."}],["$","h2",null,{"children":"Audit"}],["$","p",null,{"children":"Enterprise activity monitoring."}]]}],null,["$","$L2",null,{"children":["$","$3",null,{"name":"Next.MetadataOutlet","children":"$@4"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"rcFk8HKwLw_Qd-j8KTdOd"}
4:null
