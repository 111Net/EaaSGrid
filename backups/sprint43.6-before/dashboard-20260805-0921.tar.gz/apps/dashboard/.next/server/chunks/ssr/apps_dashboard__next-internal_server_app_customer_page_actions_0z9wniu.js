module.exports=[67971,(a,b,c)=>{}];

//# sourceMappingURL=apps_dashboard__next-internal_server_app_customer_page_actions_0z9wniu.js.map