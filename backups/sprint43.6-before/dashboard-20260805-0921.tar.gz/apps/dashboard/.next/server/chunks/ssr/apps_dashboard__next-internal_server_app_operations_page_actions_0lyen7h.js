module.exports=[73672,(a,b,c)=>{}];

//# sourceMappingURL=apps_dashboard__next-internal_server_app_operations_page_actions_0lyen7h.js.map