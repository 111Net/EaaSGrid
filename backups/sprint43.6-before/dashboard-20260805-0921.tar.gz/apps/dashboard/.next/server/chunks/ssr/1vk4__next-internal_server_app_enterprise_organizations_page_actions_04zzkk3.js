module.exports=[51680,(a,b,c)=>{}];

//# sourceMappingURL=1vk4__next-internal_server_app_enterprise_organizations_page_actions_04zzkk3.js.map