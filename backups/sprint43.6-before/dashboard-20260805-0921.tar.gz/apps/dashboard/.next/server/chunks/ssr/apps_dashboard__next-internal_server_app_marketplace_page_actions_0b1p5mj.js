module.exports=[10832,(a,b,c)=>{}];

//# sourceMappingURL=apps_dashboard__next-internal_server_app_marketplace_page_actions_0b1p5mj.js.map