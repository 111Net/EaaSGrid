module.exports=[23956,(a,b,c)=>{}];

//# sourceMappingURL=044u_dashboard__next-internal_server_app_enterprise_governance_page_actions_0k7j4r3.js.map