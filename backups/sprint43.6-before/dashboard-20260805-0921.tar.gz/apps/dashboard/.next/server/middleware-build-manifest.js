globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/rcFk8HKwLw_Qd-j8KTdOd/_buildManifest.js",
    "static/rcFk8HKwLw_Qd-j8KTdOd/_ssgManifest.js",
    "static/rcFk8HKwLw_Qd-j8KTdOd/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/1jq4o6yq14o4c.js",
    "static/chunks/07-hzktxqjvzd.js",
    "static/chunks/3rxl-jt3pdxgx.js",
    "static/chunks/3ph-k7hes6w94.js",
    "static/chunks/turbopack-2tz8zrn_1yit9.js"
  ]
};
