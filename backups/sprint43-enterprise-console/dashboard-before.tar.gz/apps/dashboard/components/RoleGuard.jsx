"use client";

export default function RoleGuard({

  role,

  allowed,

  children

}) {

  if (!allowed.includes(role)) {

    return (

      <div>

        <h2>Access Denied</h2>

        <p>
          You do not have permission to access this module.
        </p>

      </div>

    );

  }

  return children;

}
