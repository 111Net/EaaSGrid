export default function ModuleCard({ module }) {

  return (

    <div
      style={{
        border: "1px solid #ddd",
        borderRadius: "10px",
        padding: "20px",
        marginBottom: "15px"
      }}
    >

      <h3>{module.title}</h3>

      <p>{module.description}</p>

      <a href={module.href}>
        Open Module →
      </a>

    </div>

  );

}
