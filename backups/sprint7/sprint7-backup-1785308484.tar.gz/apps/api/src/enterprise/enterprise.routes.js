
const express=require("express");

const router=express.Router();


router.get("/tenants",(req,res)=>{

res.json({

tenants:[],
status:"enterprise-ready"

});

});


module.exports=router;

