
const express=require("express");

const router=express.Router();


router.get("/status",(req,res)=>{

res.json({

service:"XaaSGrid AI Engine",
status:"operational",
models:0

});

});


router.get("/prediction",(req,res)=>{

res.json({

prediction:"normal",
confidence:0,
recommendation:"No action required"

});

});


module.exports=router;

