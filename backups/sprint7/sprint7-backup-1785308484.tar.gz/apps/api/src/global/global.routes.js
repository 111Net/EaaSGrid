
const express=require("express");

const router=express.Router();


router.get("/regions",(req,res)=>{

res.json({

regions:[],
platform:"global-ready"

});

});


module.exports=router;

