const express = require("express");

const router = express.Router();

const {
  getDashboard,
} = require("../controllers/dashboard.controller");

router.get("/", getDashboard);

module.exports = router;


// XaaSGrid Control Centre compatibility route

router.get("/summary", async (req,res)=>{

    try {

        const dashboard =
        await dashboardService.getDashboardData();


        res.json({

            success:true,

            data:dashboard

        });


    } catch(error){

        console.error(error);


        res.status(500).json({

            success:false,

            message:"Dashboard summary unavailable"

        });

    }

});


