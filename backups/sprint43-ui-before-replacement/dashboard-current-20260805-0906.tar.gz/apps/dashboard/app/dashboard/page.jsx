"use client";


import Sidebar from "../../components/Sidebar";
import ModuleCard from "../../components/ModuleCard";
import {MODULES} from "../../lib/moduleRegistry";


export default function DashboardPage(){


const role="SUPER_ADMIN";


const modules =
MODULES[role] || [];



const health=[

["API","ONLINE"],
["Database","ONLINE"],
["Redis","ONLINE"],
["Dashboard","ONLINE"]

];



const metrics=[

["Organizations","25"],
["Tenants","142"],
["Customers","1,840"],
["Availability","99.95%"]

];



return (

<div
style={{
display:"flex",
background:"#f3f4f6",
minHeight:"100vh"
}}
>


<Sidebar role={role}/>



<main
style={{
flex:1,
padding:"35px"
}}
>


<h1>
XaaSGrid Enterprise Console
</h1>


<p>
Enterprise administration and governance platform
</p>



<h2>
Platform Health
</h2>


<div
style={{
display:"grid",
gridTemplateColumns:"repeat(4,1fr)",
gap:"15px"
}}
>


{
health.map(
(item)=>(

<div
key={item[0]}
style={{
background:"white",
padding:"20px",
borderRadius:"10px"
}}
>

<h3>
{item[0]}
</h3>

<p>
{item[1]}
</p>


</div>

)

)

}


</div>




<h2>
Enterprise Overview
</h2>



<div
style={{
display:"grid",
gridTemplateColumns:"repeat(4,1fr)",
gap:"15px"
}}
>


{
metrics.map(
(item)=>(

<div
key={item[0]}
style={{
background:"white",
padding:"20px",
borderRadius:"10px"
}}
>

<h3>
{item[0]}
</h3>

<strong>
{item[1]}
</strong>

</div>

)

)

}


</div>





<h2>
Platform Modules
</h2>


{
modules.map(
(module)=>(

<ModuleCard
key={module.route}
module={module}
/>

)

)
}



</main>


</div>


);

}
