"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";

export default function Home(){

const router = useRouter();

useEffect(()=>{

router.replace("/dashboard");

},[router]);


return (

<div
style={{
padding:"40px",
fontFamily:"Arial"
}}
>

<h2>
Loading XaaSGrid Enterprise Console...
</h2>

</div>

);

}
