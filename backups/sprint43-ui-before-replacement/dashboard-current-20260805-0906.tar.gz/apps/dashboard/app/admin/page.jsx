export default function Admin(){

return (

<div style={{padding:"40px"}}>

<h1>
XaaSGrid Administration
</h1>

<p>
Platform administration and configuration
</p>

</div>

);

}
