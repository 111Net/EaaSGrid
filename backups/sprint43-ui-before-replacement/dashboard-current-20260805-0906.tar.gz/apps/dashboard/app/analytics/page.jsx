export default function Analytics(){

return (

<div style={{padding:"40px"}}>

<h1>
XaaSGrid Analytics Engine
</h1>

<p>
Platform metrics and AI recommendations
</p>

</div>

);

}
