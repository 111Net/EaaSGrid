"use client";

import Link from "next/link";

export default function Sidebar({role}){


const items=[
["Dashboard","/dashboard"],
["Enterprise","/enterprise"],
["Customers","/customer"],
["Operations","/operations"],
["Analytics","/analytics"],
["Marketplace","/marketplace"],
["Administration","/admin"]
];


return (

<div
style={{
width:"260px",
minHeight:"100vh",
background:"#111827",
color:"white",
padding:"25px"
}}
>


<h2>
XaaSGrid
</h2>


<p>
{role}
</p>


<hr/>


{
items.map(
(item)=>(

<div
key={item[1]}
style={{
margin:"15px 0"
}}
>

<Link
href={item[1]}
style={{
color:"white",
textDecoration:"none"
}}
>

{item[0]}

</Link>


</div>

)

)

}


</div>

);

}
